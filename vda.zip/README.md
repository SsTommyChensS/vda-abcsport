# VIETAIDATA Website

This project is a responsive website for VIETAIDATA assignment. The website is built using HTML, CSS, and JavaScript, with the help of Bootstrap and Swiper.js for responsiveness and interactivity

## Technologies Used

- HTML
- CSS
- JavaScript
- [Bootstrap](https://getbootstrap.com/)
- [Swiper.js](https://swiperjs.com/)

## Live demo

https://sstommychenss.github.io/vda-abcsport/